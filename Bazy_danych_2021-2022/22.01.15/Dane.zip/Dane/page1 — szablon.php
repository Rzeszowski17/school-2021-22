<!DOCTYPE HTML>

<HTML>
<HEAD>
	<link rel="stylesheet" href="main.css">
	<meta charset="UTF-8">
	<title>Prezenty Świąteczne</title>
	<script>
	</script>	

</HEAD>


<BODY>
	<div class="baner1">
		<h1>PREZENTY ŚWIĄTECZNE</h1>
	</div>
	
	<div class="baner2">
		<div class="odnosnik"><a href="./page1.html">Page1</a>
		</div>
	</div>
	
	
	
	<div class="lewy1">
		<h2>TWÓJ KOSZYK</h2>
		
		
	
		

	</div>
	
	<div class="prawy1">
		<h2 id="kwota">KWOTA DO ZAPŁATY:</h2>
					
	</div>
	
	<div class="stopka">
		
	</div>

</BODY>

</HTML>
